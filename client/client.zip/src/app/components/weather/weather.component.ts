import { Component, OnInit } from '@angular/core';

import { WeatherResponse } from '../../models/response/weather.response.model';
import { WeatherService } from '../../services/weather.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Weather } from '../../models/weather.model';
import { jqxChartModule } from 'jqwidgets-ng/jqxchart';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-weather',
  standalone: true,
  imports: [jqxChartModule, CommonModule],
  providers: [],
  templateUrl: './weather.component.html',
  styleUrls: ['./weather.component.css'],
})
class WeatherComponent implements OnInit {
  weather: Weather[] = [];
  sampleData: any[] = [
    { Day: 'Monday', Sensor2: 30, Sensor1: 10, Cycling: 25, Goal: 40 },
    { Day: 'Tuesday', Sensor2: 25, Sensor1: 15, Cycling: 10, Goal: 50 },
    { Day: 'Wednesday', Sensor2: 30, Sensor1: 10, Cycling: 25, Goal: 60 },
    { Day: 'Thursday', Sensor2: 40, Sensor1: 20, Cycling: 25, Goal: 40 },
    { Day: 'Friday', Sensor2: 45, Sensor1: 20, Cycling: 25, Goal: 50 },
    { Day: 'Saturday', Sensor2: 30, Sensor1: 20, Cycling: 30, Goal: 60 },
    { Day: 'Sunday', Sensor2: 20, Sensor1: 30, Cycling: 10, Goal: 90 }
  ];
  padding: any = { left: 10, top: 10, right: 15, bottom: 10 };
  titlePadding: any = { left: 90, top: 0, right: 0, bottom: 10 };
  getWidth(): any {
    if (document.body.offsetWidth < 850) {
      return '90%';
    }

    return 850;
  }

  xAxis: any =
    {
      dataField: 'Day',
      unitInterval: 1,
      tickMarks: { visible: true, interval: 1 },
      gridLinesInterval: { visible: true, interval: 1 },
      valuesOnTicks: false,
      padding: { bottom: 10 }
    };
  valueAxis: any =
    {
      unitInterval: 10,
      minValue: 0,
      maxValue: 50,
      title: { text: 'Humidity<br><br>' },
      labels: { horizontalAlignment: 'right' }
    };
  seriesGroups: any[] =
    [
      {
        type: 'line',
        series:
          [
            {
              dataField: 'Sensor1',
              symbolType: 'square',
              labels:
              {
                visible: true,
                backgroundColor: '#FEFEFE',
                backgroundOpacity: 0.2,
                borderColor: '#7FC4EF',
                borderOpacity: 0.7,
                padding: { left: 5, right: 5, top: 0, bottom: 0 }
              }
            },
            {
              dataField: 'Sensor2',
              symbolType: 'circle',
              labels:
              {
                visible: true,
                backgroundColor: '#FEFEFE',
                backgroundOpacity: 0.2,
                borderColor: '#7FC4EF',
                borderOpacity: 0.7,
                padding: { left: 5, right: 5, top: 0, bottom: 0 }
              }
            }
          ]
      }
    ];

  constructor(private weatherService: WeatherService) {
  }

  ngOnInit(): void {
    this.weatherService.getStations()
      .then((data: WeatherResponse) => {
        this.weather = data.weather;
        console.log(this.weather);
      })
      .catch((error: HttpErrorResponse) => (console.error(`Failed to fetch: ${error.message}`)));
  }
}

export { WeatherComponent };