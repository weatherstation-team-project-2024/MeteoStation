export interface Weather {
    lsid: number;
    ts: number;
    hum?: number;
    temp?: number;
    pm_2p5?: number;
}