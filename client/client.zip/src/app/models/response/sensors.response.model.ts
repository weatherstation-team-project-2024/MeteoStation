import { Sensor } from '../sensor.model';

export interface SensorsResponse {
  sensors: Sensor[];
}